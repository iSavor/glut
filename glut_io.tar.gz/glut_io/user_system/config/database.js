module.exports = {
	url: 'mongodb://localhost/glut_data'
};